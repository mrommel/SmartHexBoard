class Tests:
    are_running: bool = False
