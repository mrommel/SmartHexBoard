from smarthexboardlib.core.base import ExtendedEnum


class EnvoyEffectLevel(ExtendedEnum):
	sixth = 'sixth'
	first = 'first'
	third = 'third'
	suzerain = 'suzerain'
