class CityConnections:
	def __init__(self, player):
		self.player = player

	def doTurn(self, simulation):
		pass