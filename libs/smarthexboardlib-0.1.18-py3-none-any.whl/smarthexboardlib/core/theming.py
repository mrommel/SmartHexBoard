from enum import Enum


class Color(Enum):
	white = 'white'
	red = 'red'
	orange = 'orange'
	magenta = 'magenta'
	blue = 'blue'
	yellow = 'yellow'
