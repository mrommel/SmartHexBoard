from smarthexboardlib.map.base import HexPoint

invalidHexPoint = HexPoint(-1, -1)

maxTurnsSafeEstimate: int = 9999  # MAX_TURNS_SAFE_ESTIMATE
